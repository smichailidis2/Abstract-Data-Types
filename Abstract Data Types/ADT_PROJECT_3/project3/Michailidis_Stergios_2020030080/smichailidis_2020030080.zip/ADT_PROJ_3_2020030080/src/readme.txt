

Counters in AVL tree:

for each insertiion, a total of 

