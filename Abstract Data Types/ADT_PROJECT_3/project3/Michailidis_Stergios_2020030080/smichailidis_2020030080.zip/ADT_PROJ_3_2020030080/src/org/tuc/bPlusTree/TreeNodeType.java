package org.tuc.bPlusTree;

enum TreeNodeType {
    TREE_LEAF,
    TREE_INTERNAL_NODE,
    TREE_ROOT_INTERNAL,
    TREE_ROOT_LEAF,
    TREE_LEAF_OVERFLOW,
    TREE_LOOKUP_OVERFLOW
}