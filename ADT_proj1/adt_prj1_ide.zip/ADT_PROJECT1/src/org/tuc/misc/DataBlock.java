package org.tuc.misc;

import java.io.Serializable;

public class DataBlock {

	private ByteSegment bs = null;
	private int blockNo = -1;
	private int next_blockNo = -1;
	private int last_int_idx = -1;
	
	
	
	public int getLast_int_idx() {
		return last_int_idx;
	}


	public void setLast_int_idx(int last_int_idx) {
		this.last_int_idx = last_int_idx;
		bs.putInt(last_int_idx, 1);
	}


	public DataBlock(){		
		bs = new ByteSegment();	
		//Initialise segment header
		bs.putInt(-1, 0); 		//set initialise value for blockNo
		blockNo = -1;
		bs.putInt(-1, 1); 		//set initialise value for lastIndex
		next_blockNo = -1;
		bs.putInt(-1, 2); 		//set initialise value for nextblockNo
		last_int_idx = -1;
	}

	
	public DataBlock(byte[] byteseg){
		
		bs = new ByteSegment(byteseg);
		//get segment header
		blockNo = bs.getInt(0);
		last_int_idx = bs.getInt(1);
		next_blockNo = bs.getInt(2);
		
	}
	
	
	public int append(int value1, int value2){
		
		if (last_int_idx <= 61) { 
		//if (last_int_idx <= 5) { TODO UNIT TESTING
			if (last_int_idx == -1) {
				bs.putInt(value1, 4);
				bs.putInt(value2, 5);
				last_int_idx = 5;
			} else {
				bs.putInt(value1, ++last_int_idx);
				bs.putInt(value2, ++last_int_idx);
			}
			
			bs.putInt(last_int_idx,1);
			
			return last_int_idx;
		} else {
			return -1;
		}
	}
	

	public boolean search(int value1, int value2){
		
		for(int i=4; i<=last_int_idx; ){
			int x = bs.getInt(i++);
			int y = bs.getInt(i++);
			
			if (x==value1 && y==value2){
				return true;
			}
		}
		
		return false;
		
		
	}
	
	public int getValue(int index) {
		
		if (index < 4 || index > 63) {
			return -1; //not valid value
		}
		
		return bs.getInt(index);
	}
	
	
	public int getBlockNo() {
		return blockNo;
	}

	
	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
		bs.putInt(blockNo, 0);
	}
	
	
	//converts array of bytes o array of integers and returns byte[]
	public byte[] convertToByteArray(){
		return bs.int_to_byte_segment();
	}


	public int getNext_blockNo() {
		return next_blockNo;
	}


	public void setNext_blockNo(int next_blockNo) {
		this.next_blockNo = next_blockNo;
		bs.putInt(next_blockNo, 2);
	}
	

	
	public ByteSegment getByteSegment() {
		return bs;
	}


	@Override
	public String toString() {
		return "DataBlock [blockNo=" + blockNo + ", next_blockNo=" + next_blockNo + ", last_int_idx=" + last_int_idx
				+ "]";
	}
	
	
	
}
