package org.tuc.misc;

public class Coordinates{
	
	//Coordinate data;
	//(x,y)
	
	private int x;
	private int y;
	
	//constructor 1
	public Coordinates(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	//constructor 2
	public Coordinates() {
		this.x = 0;
		this.y = 0;
	}
	
	
	//getters & setters
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	
	//to string
	@Override
	public String toString() {
		return "x=" + x + ", y=" + y;
	}
	
	
	
	
}
