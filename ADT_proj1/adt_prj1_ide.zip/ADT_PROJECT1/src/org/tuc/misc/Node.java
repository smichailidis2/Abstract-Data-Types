package org.tuc.misc;

public class Node{
	
	//Node used in list;
	
	private Coordinates data;
	private Node nextNode;
	
	public Node (Coordinates c) {
		this.data = c;
		this.nextNode = null;
	}
	
	public Node (int x, int y) {
		Coordinates d = new Coordinates(x,y);
		this.data = d;
		this.nextNode = null;
	}
	
	//getters & setters
	public Coordinates getData() {
		return data;
	}
	
	public void setData(Coordinates c) {
		this.data = c;
	}
	
	public Node getNextNode() {
		return nextNode;
	}
	
	public void setNextNode(Node n) {
		this.nextNode = n;
	}
	
	//comparison function, returns 0 if coordinates match and -1 if they do not.
	public int compare(Coordinates c) {
		if (  (this.data.getX() == c.getX()) && (this.data.getY() == c.getY())  )
			return 0;
		else
			return -1;
	}
	
}
