package org.tuc.misc;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

public class ByteSegment {
	
	private byte[] b_data_seg = null;
	private int[] i_data_seg = null;
	
	
	public int[] getI_data_seg() {
		return i_data_seg;
	}



	//https://stackoverflow.com/questions/11437203/how-to-convert-a-byte-array-to-an-int-array
	//https://stackoverflow.com/questions/9431526/find-endianness-of-system-in-java	
	public ByteSegment(){		
		 b_data_seg = new byte[256];
		 
		 IntBuffer intBuf =
				   ByteBuffer.wrap(b_data_seg)
				     .order(ByteOrder.BIG_ENDIAN)
				     .asIntBuffer();
		 i_data_seg = new int[intBuf.remaining()];
		 intBuf.get(i_data_seg);
		 
	}
	
	

	public ByteSegment(byte[] b_array){	
		 b_data_seg = b_array;
		 
		 IntBuffer intBuf =
				   ByteBuffer.wrap(b_data_seg)
				     .order(ByteOrder.BIG_ENDIAN)
				     .asIntBuffer();
		 i_data_seg = new int[intBuf.remaining()];
		 intBuf.get(i_data_seg);
		 
	}
	
	
	
	public void putInt(int value, int idx){
		i_data_seg[idx] = value;
	}
	
	
	//throw exception event !!!!!
	public int getInt(int idx){
		return i_data_seg[idx];
	}
	
	

	//https://stackoverflow.com/questions/1086054/how-to-convert-int-to-byte
	public byte[] int_to_byte_segment(){

        ByteBuffer byteBuffer = ByteBuffer.allocate(256);        
        IntBuffer intBuffer = byteBuffer.asIntBuffer();
        intBuffer.put(i_data_seg);

        return byteBuffer.array();
		
	}
}
