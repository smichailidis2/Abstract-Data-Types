package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Test;
import org.tuc.discLists.DiscHashLinkedList;
import org.tuc.discLists.DiscList;
import org.tuc.hashList.HashLinkedList;
import org.tuc.linkedlist.List;
import org.tuc.misc.Coordinates;

public class LoadCoordinatesTest {
	
	private static String FILENAME = "C:\\work\\dir\\K1k.bin";
	private static String listname = "C:\\work\\dir\\listloadtest1";
	private static String hashlistname = "C:\\work\\dir\\hashlistloadtest1";

	List list = new List();
	HashLinkedList hash = new HashLinkedList();
	
	DiscList disclist = new DiscList(listname);
	DiscHashLinkedList dischash = new DiscHashLinkedList(hashlistname);
	
	@Test
	public void loadcoordinatesinlist_test() {
		
		//load coordinates in list (test conducted with 1000 coordinates)
		int i = load(FILENAME);
		
		assertEquals(1000, i);
		
		
		//memory list searches
		int s1 = list.findNode(new Coordinates(111830,84367));
		int s2 = list.findNode(new Coordinates());
		
		System.out.println("");
		
		//memory hash list searches
		int hs1 = hash.findNode(new Coordinates(64159,127033));
		int hs2 = hash.findNode(new Coordinates());
		
		int hs3 = hash.findNode(new Coordinates(202842,218319)); //hash value = 67
		int hs4 = hash.findNode(new Coordinates(72266,243263));  //hash value = 67
		
		
		//disc list searches
		
		int ds1  = disclist.findNode(new Coordinates(32070,100261));	//start of data block 0 (number of searches == 1)
		int ds2  = disclist.findNode(new Coordinates(126939,51641));
		int ds3  = disclist.findNode(new Coordinates(75937,204281));
		int ds4  = disclist.findNode(new Coordinates(111830,84367));
		int ds5  = disclist.findNode(new Coordinates(79576,245630));
		int ds6  = disclist.findNode(new Coordinates(225826,49176));
		int ds7  = disclist.findNode(new Coordinates(131255,220480));
		int ds8  = disclist.findNode(new Coordinates(2054,214415));
		int ds9  = disclist.findNode(new Coordinates(234987,246475));
		int ds10 = disclist.findNode(new Coordinates(65694,62500));
		int ds11 = disclist.findNode(new Coordinates(49328,100714));
		int ds12 = disclist.findNode(new Coordinates(134911,249604));
		int ds13 = disclist.findNode(new Coordinates(210825,161226));
		int ds14 = disclist.findNode(new Coordinates(117176,237117));
		int ds15 = disclist.findNode(new Coordinates(183179,191630));
		int ds16 = disclist.findNode(new Coordinates(255674,237063));
		int ds17 = disclist.findNode(new Coordinates(173808,27071));
		int ds18 = disclist.findNode(new Coordinates(255654,257549));
		int ds19 = disclist.findNode(new Coordinates(136273,65618));
		int ds20 = disclist.findNode(new Coordinates(149808,96796));
		int ds21 = disclist.findNode(new Coordinates(117323,159597));
		int ds22 = disclist.findNode(new Coordinates(195202,251813));
		int ds23 = disclist.findNode(new Coordinates(166356,136041));
		int ds24 = disclist.findNode(new Coordinates(14724,171682));
		int ds25 = disclist.findNode(new Coordinates(208146,213052));
		int ds26 = disclist.findNode(new Coordinates(82024,244730));
		int ds27 = disclist.findNode(new Coordinates(143025,159724));
		int ds28 = disclist.findNode(new Coordinates(261837,198147));
		int ds29 = disclist.findNode(new Coordinates(26142,108861));
		int ds30 = disclist.findNode(new Coordinates(145488,216769));
		int ds31 = disclist.findNode(new Coordinates(1722,133438));
		int ds32 = disclist.findNode(new Coordinates(146931,214272));
		int ds33 = disclist.findNode(new Coordinates(160240,241700));
		int ds34 = disclist.findNode(new Coordinates(70927,90992));
		int ds35 = disclist.findNode(new Coordinates(83783,248713));
		int ds36 = disclist.findNode(new Coordinates(8940,43493));
		int ds37 = disclist.findNode(new Coordinates(165325,108794));
		int ds38 = disclist.findNode(new Coordinates(129187,246994));
		int ds39 = disclist.findNode(new Coordinates(163543,92184));
		int ds40 = disclist.findNode(new Coordinates(260916,159064));
		int ds41 = disclist.findNode(new Coordinates(18613,91178));
		int ds42 = disclist.findNode(new Coordinates(143859,214939));
		int ds43 = disclist.findNode(new Coordinates(34552,70724));
		int ds44 = disclist.findNode(new Coordinates(157443,136494));
		int ds45 = disclist.findNode(new Coordinates(115306,182695));
		int ds46 = disclist.findNode(new Coordinates(140574,22049));
		int ds47 = disclist.findNode(new Coordinates(141826,88144));
		int ds48 = disclist.findNode(new Coordinates(224750,219381));
		int ds49 = disclist.findNode(new Coordinates(196565,135282));
		int ds50 = disclist.findNode(new Coordinates(112612,167437));
		int ds51 = disclist.findNode(new Coordinates(165836,42431));
		int ds52 = disclist.findNode(new Coordinates(61952,209282));
		int ds53 = disclist.findNode(new Coordinates(62920,169231));
		int ds54 = disclist.findNode(new Coordinates(65183,68975));
		int ds55 = disclist.findNode(new Coordinates(43250,136732));
		int ds56 = disclist.findNode(new Coordinates(196051,244965));
		int ds57 = disclist.findNode(new Coordinates(21961,31834));
		int ds58 = disclist.findNode(new Coordinates(124235,161947));
		int ds59 = disclist.findNode(new Coordinates(17540,78820));
		int ds60 = disclist.findNode(new Coordinates(153845,249482));
		
		int ds61 = disclist.findNode(new Coordinates(175322,135096));	//start of data block 1 (number of searches == 2)
		int ds62 = disclist.findNode(new Coordinates(171349,239584));
		int ds63 = disclist.findNode(new Coordinates(48451,193795));
		int ds64 = disclist.findNode(new Coordinates(232216,192296)); 

		
		//assertions for memory
		
		//list
		System.out.println("");
		assertEquals(4,s1);
		assertEquals(-1,s2);
		
		System.out.println("");
		
		//hash
		assertTrue( hs1 != -1);
		assertEquals(-1, hs2);
		assertEquals(1,hs3);
		assertEquals(2,hs4);
	
	
		//assertions for disc
		
		//list
		assertEquals(1,ds1 );	//data block 1 => 1 disc access
		assertEquals(1,ds2 );
		assertEquals(1,ds3 );
		assertEquals(1,ds4 );
		assertEquals(1,ds5 );
		assertEquals(1,ds6 );
		assertEquals(1,ds7 );
		assertEquals(1,ds8 );
		assertEquals(1,ds9 );
		assertEquals(1,ds10);
		assertEquals(1,ds11);
		assertEquals(1,ds12);
		assertEquals(1,ds13);
		assertEquals(1,ds14);
		assertEquals(1,ds15);
		assertEquals(1,ds16);
		assertEquals(1,ds17);
		assertEquals(1,ds18);
		assertEquals(1,ds19);
		assertEquals(1,ds20);
		assertEquals(1,ds21);
		assertEquals(1,ds22);
		assertEquals(1,ds23);
		assertEquals(1,ds24);
		assertEquals(1,ds25);
		assertEquals(1,ds26);
		assertEquals(1,ds27);
		assertEquals(1,ds28);
		assertEquals(1,ds29);
		assertEquals(1,ds30);
		
		assertEquals(2,ds31);	//data block 2 => 2disc accesses
		assertEquals(2,ds32);
		assertEquals(2,ds33);
		assertEquals(2,ds34);
		assertEquals(2,ds35);
		assertEquals(2,ds36);
		assertEquals(2,ds37);
		assertEquals(2,ds38);
		assertEquals(2,ds39);
		assertEquals(2,ds40);
		assertEquals(2,ds41);
		assertEquals(2,ds42);
		assertEquals(2,ds43);
		assertEquals(2,ds44);
		assertEquals(2,ds45);
		assertEquals(2,ds46);
		assertEquals(2,ds47);
		assertEquals(2,ds48);
		assertEquals(2,ds49);
		assertEquals(2,ds50);
		assertEquals(2,ds51);
		assertEquals(2,ds52);	
		assertEquals(2,ds53);
		assertEquals(2,ds54);
		assertEquals(2,ds55);
		assertEquals(2,ds56);
		assertEquals(2,ds57);
		assertEquals(2,ds58);
		assertEquals(2,ds59);
		assertEquals(2,ds60);
		
		assertEquals(3,ds61);	//data block 3 => 3 disc accesses
		assertEquals(3,ds62);
		assertEquals(3,ds63);
		assertEquals(3,ds64);
		
		
		//hash
		int hds1 = dischash.findNode(new Coordinates(202842,218319));
		int hds2 = dischash.findNode(new Coordinates(72266,243263));
				
		assertEquals(1,hds1);
		assertEquals(1,hds2);


	}
	
	//returns number of loaded coordinates
	//Coordinates read from a given file are loaded into all data structures.
	//At the same time, filename.bin100 file is created containing 100 random coordinates read from 
	//a given bin file.
	private int load(String filename2) {
		DataInputStream input = null;
		int x,y;
		int n=0;
		int nmax = 2<<17;
		
		//check if file exists
		File f = new File(filename2);
		
		if ( !f.exists() ) {
			System.out.println("ERROR : FILE NOT FOUND;");
			return 0;
		}
		
		
		//open file for read
		try {
			input = new DataInputStream(new BufferedInputStream(new FileInputStream(filename2)));
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
			return 0;
		}
		
		try {
			
			int counter = 1;
			while (((x=input.readInt()) != -1)) {
				System.out.println("counter = " + counter);
				
				y = input.readInt();
				
				if (!(x >=0 && x<nmax) || !(y >=0 && y<nmax)) {
					System.out.println("xy out of range");
					System.out.println("file NOT loaded");
					n = 0;
					break;
				} else {
					System.out.println("x=" + x + "  y=" + y);
					
					Coordinates c = new Coordinates(x,y);
					
					//append coordinates read
					list.addNode(c);
					hash.addNode(c);
					
					disclist.addNode(c);
					dischash.addNode(c);
					
				}
				++counter;
				++n;				
			}
									
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
		}
		
		try {
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return n;
	}
	
	
}
