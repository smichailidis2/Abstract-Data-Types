package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Test;
import org.tuc.discLists.DiscList;
import org.tuc.misc.Coordinates;
import org.tuc.misc.DataBlock;

public class DiscListTest {
	
	@Test
	public void disclisttest() {
		
		String filename = "C:\\work\\disc_tests\\dl_test1";
		DiscList dl = new DiscList(filename);
		
		//check if file is created
		File f = new File(filename + ".lst");
		assertTrue(f.exists());
		
		dl.close_list();
		
		
		dl = new DiscList(filename);
		
		Coordinates c1 = new Coordinates(1,1);
		Coordinates c2 = new Coordinates(9,1);
		Coordinates c3 = new Coordinates(32,7);
		Coordinates c4 = new Coordinates(155,0);
		Coordinates c5 = new Coordinates();
		Coordinates c6 = new Coordinates(69,69);
		Coordinates c7 = new Coordinates(11,84);		

		dl.addNode(c1);
		dl.addNode(c2);
		dl.addNode(c3);
		dl.addNode(c4);
		dl.addNode(c5);
		dl.addNode(c6);
		dl.addNode(c7);
		
		assertEquals(1, dl.findNode(c1));
		assertEquals(1, dl.findNode(c2));
		assertEquals(1, dl.findNode(c3));
		assertEquals(1, dl.findNode(c4));
		assertEquals(1, dl.findNode(c5));
		assertEquals(1, dl.findNode(c6));
		assertEquals(1, dl.findNode(c7));

		dl.close_list();
		
	}
}
