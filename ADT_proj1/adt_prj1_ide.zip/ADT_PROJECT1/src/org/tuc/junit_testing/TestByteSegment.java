package org.tuc.junit_testing;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;
import org.tuc.misc.ByteSegment;

public class TestByteSegment {
	
	@Test
	public void testbytesegment() {
		
		
		//new instance of Byte Segment
		//The goal of ByteSegment class is to handle byte array as array of integers
		ByteSegment bs = new ByteSegment();
		
		//check empty array of integers created by ByteSegment class
		int[] i_array = new int[64];
		assertArrayEquals(i_array, bs.getI_data_seg());
		
		//check empty array of bytes created by ByteSegment class
		byte[] b_array = new byte[256];
		assertArrayEquals(b_array,bs.int_to_byte_segment());
		
		//**************************************************************************
		
		
		/*
		 * Check first constructor of ByteSegment - create 0 values byte and integer array
		 * 
		 * 1. test scenario
		 * Put values into integer array and check
		 * Convert integer array to byte array and check corresponding byte values of previously 
		 * stored integer values
		 */
		
		//put values into integer array
		bs.putInt(1, 0);
		assertEquals(bs.getInt(0) , 1);
		
		bs.putInt(319, 60);
		assertEquals(bs.getInt(60), 319);
		
		
		//convert array of integers to array of bytes
		byte[] ba = bs.int_to_byte_segment();
				
		assertEquals(ba[3] , 1);
		
		//319 in decimal => 00000001 00111111 in binary => 256 + 63
		assertEquals(ba[243],63);
		assertEquals(ba[242],1);
		

		//**************************************************************************
		
		
		/*
		 * Check second constructor of ByteSegment - byte array is passed as parameter
		 * 
		 * 2. test scenario
		 * Create byte array.
		 * Modify some values of said array, check corresponding integer values
		 * Convert integer values into byte array again
		 * Then double check initial byte values
		 */
		
		byte[] byte_array = new byte[256];
		
		byte_array[3] = (byte)1;   //first integer = 1
		byte_array[6] = (byte)1;   //second integer = 256
		
		//convert to integer array
		ByteSegment b0 = new ByteSegment(byte_array);
		
		assertEquals(b0.getInt(0),1);
		assertEquals(b0.getInt(1),256);
		
		
		//convert back to byte array to double check
		byte[] b = b0.int_to_byte_segment();
		
		assertEquals(b[3],1);
		assertEquals(b[6],1);
		
	}
	
}
