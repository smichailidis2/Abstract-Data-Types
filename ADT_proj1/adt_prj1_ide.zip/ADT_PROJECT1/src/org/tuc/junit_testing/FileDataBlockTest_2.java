package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;

import org.junit.Test;
import org.tuc.discLists.FileDataBlock;
import org.tuc.misc.DataBlock;

public class FileDataBlockTest_2 {
	
	@Test
	public void testFileDataBlock2() {
		
		final String FILENAME = "C:\\work\\test2.bin";
		
		FileDataBlock fdb = null;
		
		try {
			fdb = new FileDataBlock(FILENAME);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		DataBlock db1 = new DataBlock();
		
		db1.append(2, 1);
		db1.append(4, 16);
		db1.append(32, 8);
		
		fdb.appendAndUpdateBlockNo(db1);
		
		fdb.readBlockToBuffer(0);
		
		DataBlock buffer = fdb.getBuffer();
		
		
		assertTrue(buffer.search(32, 8));
		assertEquals(32,buffer.getValue(8));
		
		fdb.closeFile();
		
	}
	
}
