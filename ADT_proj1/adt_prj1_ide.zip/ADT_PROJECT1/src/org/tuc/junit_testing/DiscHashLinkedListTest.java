package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Test;
import org.tuc.discLists.DiscHashLinkedList;
import org.tuc.misc.Coordinates;

public class DiscHashLinkedListTest {
	
	private static final String FILENAME = "C:\\work\\disc_tests\\hashTest1";

	@Test
	public void testDiscHash() {
		
		//check file creation
		DiscHashLinkedList dhll = new DiscHashLinkedList(FILENAME);
		
		dhll.close_hash();
		
		File f = new File(FILENAME + ".hlst");
		assertTrue(f.exists());
		
		
		//FOT TESTING PURPORSES m=2 AND MAX INTEGERS REP DATABLOCK=2 (FOUR INTEGERS)
		//check if coordinates added
		Coordinates c1 = new Coordinates(2,7); //hash value = 295 (FOR TESTING=1)
		Coordinates c2 = new Coordinates(20,7); //hash value  (FOR TESTING=1)
		Coordinates c3 = new Coordinates(8,11); //hash value  (FOR TESTING=1)
		Coordinates c4 = new Coordinates(9,13); //hash value  (FOR TESTING=1)
		Coordinates c5 = new Coordinates(7,1); //hash value  (FOR TESTING=1)
		Coordinates c6 = new Coordinates(0,10); //hash value (FOR TESTING=0)
		
		
		dhll = new DiscHashLinkedList(FILENAME);

		dhll.addNode(c1);
		dhll.addNode(c2);
		dhll.addNode(c3);
		dhll.addNode(c4);
		dhll.addNode(c5);
		dhll.addNode(c6);
		
		assertEquals(1, dhll.findNode(c1));
		assertEquals(1, dhll.findNode(c2));
		assertEquals(1, dhll.findNode(c3));
		assertEquals(1, dhll.findNode(c4));
		assertEquals(1, dhll.findNode(c5));
		assertEquals(1, dhll.findNode(c6));
		
		//assertEquals(dhll.get_hash_array().gethashitem(295).getHEAD_BLOCK_NUMBER(),0 );
		//assertEquals(dhll.get_hash_array().gethashitem(295).getTAIL_BLOCK_NUMBER(),0 );
		//assertEquals(dhll.get_hash_array().gethashitem(1).getHEAD_BLOCK_NUMBER(),0 );
		//assertEquals(dhll.get_hash_array().gethashitem(1).getTAIL_BLOCK_NUMBER(),0 );
		
		dhll.close_hash();
		
	}
	
	
	
}
