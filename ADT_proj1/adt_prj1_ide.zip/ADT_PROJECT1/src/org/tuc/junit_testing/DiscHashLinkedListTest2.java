package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;

import org.junit.Test;
import org.tuc.discLists.DiscHashLinkedList;
import org.tuc.discLists.FileDataBlock;
import org.tuc.misc.Coordinates;

public class DiscHashLinkedListTest2 {
	
	private static final String FILENAME = "C:\\work\\dir\\hashlistloadtest1.hlst";

	@Test
	public void testDiscHash() {
		
		FileDataBlock fdb = null;
		int number_of_coord_pairs = 0;
		
		//check number of inserted coordinates
		
		try {
			fdb = new FileDataBlock(FILENAME);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		int nblocks = fdb.nextBlockno();
		System.out.println("nblocks=" + nblocks);
		
		for (int block = 0; block < nblocks; ++block) {
			
			//read block by block 
			fdb.readBlockToBuffer(block);
			
			//**************************************************************
			//count number of coordinates
			//**************************************************************
			number_of_coord_pairs += (fdb.getBuffer().getLast_int_idx()-3)/2;
			
			//************************************************************************
			//check that partially filled data block must have headr's nextoblockno=-1
			//************************************************************************
			if (fdb.getBuffer().getLast_int_idx() < 63) {
				assertEquals(true, fdb.getBuffer().getNext_blockNo() == -1);
			}
		}
		
		assertEquals(1000, number_of_coord_pairs);
		
		fdb.closeFile();;
		
		
		
		
		
		
	}
	
	
	
}
