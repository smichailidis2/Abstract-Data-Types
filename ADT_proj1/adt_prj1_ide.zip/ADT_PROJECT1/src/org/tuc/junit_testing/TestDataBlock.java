package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.tuc.misc.DataBlock;

public class TestDataBlock {
	
	@Test
	public void test_data_block() {
		
		DataBlock db = new DataBlock();
		
		assertEquals(-1,db.getBlockNo());
		assertEquals(-1,db.getLast_int_idx());
		assertEquals(-1,db.getNext_blockNo());
		
		db.append(4, 14);
		assertEquals(5,db.getLast_int_idx());
		
		db.append(345, 99);
		assertEquals(7,db.getLast_int_idx());
		
		//fill data block with coordinates and test last index
		while (db.append(10,50) != -1) {
			;
		}

		assertEquals(63,db.getLast_int_idx());
		
		
		db.setBlockNo(70);
		assertEquals(70,db.getBlockNo());
		
		db.setNext_blockNo(9);
		assertEquals(9,db.getNext_blockNo());
		
		
		
		//test 2cond constructor of DataBlock
		
		byte[] bytearray = new byte[256];
		
		//modify byte array to set block Number to be 2
		bytearray[3] = (byte)2;
		//modify last index to be 7
		bytearray[7] = (byte)7;
		//modify next block number to be -1
		bytearray[8] = (byte)0b11111111;
		bytearray[9] = (byte)0b11111111;
		bytearray[10] = (byte)0b11111111;
		bytearray[11] = (byte)0b11111111;
		
		DataBlock db1 = new DataBlock(bytearray);
		
		assertEquals(2,db1.getBlockNo());
		assertEquals(7,db1.getLast_int_idx());
		assertEquals(-1,db1.getNext_blockNo());

		
	}
}
