package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.tuc.hashList.HashLinkedList;
import org.tuc.misc.Coordinates;
import org.tuc.misc.Node;

public class HashListTest {
	
	@Test
	public void hashTest() {
		
		HashLinkedList hash = new HashLinkedList();
		
		assertEquals(500,hash.hash_size());
		assertEquals(262144,hash.getN());
		
		Coordinates c1 = new Coordinates(1,2);
		//hash value = 262146 modulo 500 = 146
		Coordinates c2 = new Coordinates(2,4);
		//hash value = 524292 modulo 500 = 292
		Coordinates c3 = new Coordinates();
		//hash value = 0 modulo 500 = 0
		Coordinates c4 = new Coordinates(2,0);
		//hash value = 524288 modulo 500 = 288
		
		hash.addNode(c1);
		hash.addNode(c2);
		hash.addNode(c3);
		hash.addNode(c4);
		
		assertEquals(146,hash.hash_map_function(c1));
		assertEquals(292,hash.hash_map_function(c2));
		assertEquals(0,hash.hash_map_function(c3));
		assertEquals(288,hash.hash_map_function(c4));
		
		assertEquals(1,hash.findNode(c1));
		assertEquals(1,hash.findNode(c2));
		assertEquals(1,hash.findNode(c3));
		assertEquals(1,hash.findNode(c4));



	}
}
