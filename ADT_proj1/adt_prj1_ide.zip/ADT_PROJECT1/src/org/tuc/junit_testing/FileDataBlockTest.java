package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

import org.junit.Test;
import org.tuc.discLists.FileDataBlock;
import org.tuc.misc.DataBlock;

public class FileDataBlockTest {
	
	@Test
	public void testFileDataBlock() {
		
		final String STRINGNAME1 = "C:\\work\\test.bin";
		FileDataBlock fdb = null;
		
		//first scenario:
		//create bin file and append 5 data blocks
		
		try {
			fdb = new FileDataBlock(STRINGNAME1);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		DataBlock d1 = new DataBlock();
		DataBlock d2 = new DataBlock();
		DataBlock d3 = new DataBlock();
		DataBlock d4 = new DataBlock();
		DataBlock d5 = new DataBlock();
		
		fdb.appendAndUpdateBlockNo(d1);
		fdb.appendAndUpdateBlockNo(d2);
		fdb.appendAndUpdateBlockNo(d3);
		fdb.appendAndUpdateBlockNo(d4);
		fdb.appendAndUpdateBlockNo(d5);
		
		assertEquals(5,fdb.nextBlockno());
		
		assertEquals(0,d1.getBlockNo());
		assertEquals(1,d2.getBlockNo());
		assertEquals(2,d3.getBlockNo());
		assertEquals(3,d4.getBlockNo());
		assertEquals(4,d5.getBlockNo());

		fdb.readBlockToBuffer(0);
		assertEquals(0,fdb.getBuffer().getBlockNo());
		
		fdb.readBlockToBuffer(1);
		assertEquals(1,fdb.getBuffer().getBlockNo());
		
		fdb.readBlockToBuffer(2);
		assertEquals(2,fdb.getBuffer().getBlockNo());
		
		fdb.readBlockToBuffer(3);
		assertEquals(3,fdb.getBuffer().getBlockNo());
		
		fdb.readBlockToBuffer(4);
		assertEquals(4,fdb.getBuffer().getBlockNo());
		
		fdb.closeFile();

		
	}
}
