package org.tuc.junit_testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;
import org.tuc.linkedlist.List;
import org.tuc.misc.Coordinates;


public class ListTest {
	
	@Test
	public void testList() {
		
		List L = new List();
		
		Coordinates c1 = new Coordinates(1,2);
		Coordinates c2 = new Coordinates(138,22);
		Coordinates c3 = new Coordinates(9,243);
		Coordinates c4 = new Coordinates(80,50);
		Coordinates c5 = new Coordinates();
		Coordinates c6 = new Coordinates(166,456);
		
		L.addNode(c1);
		L.addNode(c2);
		L.addNode(c3);
		L.addNode(c4);
		L.addNode(c5);
		L.addNode(c6);

		//list size test
		int j = L.listSize();
		assertNotEquals(1, j);
		assertNotEquals(2,j);
		assertNotEquals(3,j);
		assertNotEquals(4,j);
		assertNotEquals(5,j);
		assertEquals(6,j);
		
		//find node test
		Coordinates c7 = new Coordinates(900,900);
		
		int i = L.findNode(c7);
		assertEquals(-1,i);
		
		int f = L.findNode(c1);
		assertEquals(1,f);
		
		int g = L.findNode(c2);
		assertEquals(2,g);
		
		List dummyList = new List();
		int k = dummyList.findNode(c7);
		assertEquals(-1,k);
		
	}
}
