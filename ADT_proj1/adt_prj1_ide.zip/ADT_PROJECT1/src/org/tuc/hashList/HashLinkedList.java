package org.tuc.hashList;

import org.tuc.linkedlist.List;
import org.tuc.linkedlist.ListInterface;
import org.tuc.misc.Coordinates;

public class HashLinkedList implements ListInterface{
	
	private int hasharray_size = 0;	//length is the size of hash array
	private int N = 0;				//where N = 2^18 ( max value of coordinate )
	private List[] hasharray;
	
	public HashLinkedList() {
		hasharray_size = 500;
		N = 2 << 17;
		
		hasharray = new List[hasharray_size];
	}
	
	public int hash_map_function(Coordinates c) {
		
		return (int) ( ( (long)c.getX()*N + c.getY() ) % hasharray_size );
		
	}
	
	public int hash_size() {
		return hasharray_size;
	}

	@Override
	public void addNode(Coordinates c) {
		
		int hash_index = hash_map_function(c);
		
		if (hasharray[hash_index] == null) {		//if its the first element , also initialise the list in index h
			hasharray[hash_index] = new List(); 
		}
		
		hasharray[hash_index].addNode(c); //add node to list
		System.out.println("Node added successfully in list of hash index: " + hash_index);
			
	}
	
	
	
	//returns the number of searches conducted when coordinates c found, otherwise -1;
	@Override
	public int findNode(Coordinates c) {
		
		int hash_index = hash_map_function(c);
		
		List lp = hasharray[hash_index];		//list pointer
		
		if (lp == null) 
			return -1;
		else 
			return lp.findNode(c);

	}
	
	//unit testing
	public int getN() {
		return N;
	}
	
}
