package org.tuc.discLists;

import java.io.Serializable;

public class HashItem implements Serializable{
	
	private int HEAD_BLOCK_NUMBER = -1;
	private int TAIL_BLOCK_NUMBER = -1;
	
	public HashItem (int headBlockNumber,int tailBlockNumber) {
		this.HEAD_BLOCK_NUMBER = headBlockNumber;
		this.TAIL_BLOCK_NUMBER = tailBlockNumber;
	}
	
	public HashItem () {
		//empty constructor
	}
	
	//getters & setters
	public int getHEAD_BLOCK_NUMBER() {
		return HEAD_BLOCK_NUMBER;
	}

	public void setHEAD_BLOCK_NUMBER(int hEAD_BLOCK_NUMBER) {
		HEAD_BLOCK_NUMBER = hEAD_BLOCK_NUMBER;
	}

	public int getTAIL_BLOCK_NUMBER() {
		return TAIL_BLOCK_NUMBER;
	}

	public void setTAIL_BLOCK_NUMBER(int tAIL_BLOCK_NUMBER) {
		TAIL_BLOCK_NUMBER = tAIL_BLOCK_NUMBER;
	}
	
	//toString
	@Override
	public String toString() {
		return "HashItem [ HEAD_BLOCK_NUMBER = " + HEAD_BLOCK_NUMBER + ", TAIL_BLOCK_NUMBER = " + TAIL_BLOCK_NUMBER + " ]";
	}
	
	
}
