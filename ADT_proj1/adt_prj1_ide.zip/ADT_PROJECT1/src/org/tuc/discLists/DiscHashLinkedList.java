package org.tuc.discLists;

import java.io.FileNotFoundException;
import org.tuc.linkedlist.ListInterface;
import org.tuc.misc.Coordinates;
import org.tuc.misc.DataBlock;

public class DiscHashLinkedList implements ListInterface{
	
	private String hash_list_name = "";
	private HashArray array = null;
	private FileDataBlock fdb = null;
	
	public DiscHashLinkedList (String filename) {
		this.hash_list_name = filename;
		array = new HashArray(filename);
		
		try {
			fdb = new FileDataBlock(filename + ".hlst");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}
	
	//second constructor for serialised hash array
	public DiscHashLinkedList (String filename , HashArray array) {
		this.hash_list_name = filename;
		this.array = array;
		
		try {
			fdb = new FileDataBlock(filename + ".hlst");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void addNode(Coordinates c) {
		int h_value = array.hashVaule(c);
		System.out.println(h_value);
		
		HashItem item = array.gethashitem(h_value);
		
		if (item.getHEAD_BLOCK_NUMBER() == -1) {
			//empty list
			DataBlock db = new DataBlock();
			db.append(c.getX(), c.getY());
			
			fdb.appendAndUpdateBlockNo(db);
			//after executing append , buffer contains the new DataBlock
			
			//update hash item
			item.setHEAD_BLOCK_NUMBER(fdb.getBuffer().getBlockNo());
			item.setTAIL_BLOCK_NUMBER(fdb.getBuffer().getBlockNo());
			
		} else {
			
			if ( !fdb.readBlockToBuffer(item.getTAIL_BLOCK_NUMBER()) ) return;
			
			DataBlock buffer = fdb.getBuffer();
			
			if (buffer.append(c.getX(), c.getY()) == -1) {
				//tail data block full, create new empty data block
				DataBlock new_db = new DataBlock();
				new_db.append(c.getX(), c.getY());
				
				int nextBlockNo = fdb.nextBlockno();	//get next block number from disc (must be equal to tail block number + 1)
				
				//must modify previous tail block number
				buffer.setNext_blockNo(nextBlockNo);
				
				//write both new block and modified block (buffer) to disc
				fdb.writeBuffer(buffer);
				
				//write to disc
				fdb.appendAndUpdateBlockNo(new_db);
				
				//update hash item
				item.setTAIL_BLOCK_NUMBER(nextBlockNo);

			} else {
				//insert to tail block
				fdb.writeBuffer(buffer);
			}
			
		}
		
		
		
		
	}

	
	//return number of disc accesses if element is found,
	//returns -1 otherwise
	@Override
	public int findNode(Coordinates c) {
		
		int disc_access = 0;
		
		//get hash_array[hash_value]
		int h_value = array.hashVaule(c);
		HashItem item = array.gethashitem(h_value);
		
		//get head from hash item
		int head = item.getHEAD_BLOCK_NUMBER();
		
		//check for empty list
		if (head == -1) {
			return -1;
		}
		
		//load Head Data Block to buffer 
		fdb.readBlockToBuffer(head);
		++disc_access;
		
		//flag to check if search is successful
		boolean flag = true;
		
		//search element c in buffer
		while (  !( fdb.getBuffer().search(c.getX(), c.getY()) )  ) {
			int next_block_number = fdb.getBuffer().getNext_blockNo();
			
			if (next_block_number == -1) {
				//reached end of list without finding the element
				flag = false;
				break;
			}
			
			
			//load next data block to buffer
			fdb.readBlockToBuffer(next_block_number);
			++disc_access;
		}
		
		System.out.println("FOUND ELEMENT: " + flag);
		
		return (flag) ? disc_access : -1;
		
	}
	
	
	//close file
	public void close_hash() {
		this.fdb.closeFile();
		
		HashArray.writeToFile(this.array, hash_list_name);
	}
	
	
	//for unit testing only
	public HashArray get_hash_array() {
		return this.array;
	}
	
	
}
