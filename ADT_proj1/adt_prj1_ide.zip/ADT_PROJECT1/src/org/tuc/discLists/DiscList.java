
package org.tuc.discLists;

import java.io.FileNotFoundException;
import java.io.Serializable;

import org.tuc.linkedlist.ListInterface;
import org.tuc.misc.Coordinates;
import org.tuc.misc.DataBlock;


//:=============FILE NAME CONVENTION=============:
//binary file name which contains list is : NAME.lst
//Serializable file name is : NAME.lst.ser
//:==============================================:


public class DiscList implements ListInterface{
	
	private String listname = "";
	private FileDataBlock fdb = null;
	
	private int headBlockNo = -1;
	private int tailBlockNo = -1;
	
	//name also determines file name which contains list
	public DiscList(String name) {
		this.listname = name;
		try {
			fdb = new FileDataBlock(name + ".lst");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		if (fdb.getFileLength() > 256) {		//there is at least one data block	(256 bytes)
			this.headBlockNo = 0;
			this.tailBlockNo = fdb.tailBlockNo();
		}
		
	}
	
	public void close_list() {
		this.fdb.closeFile();
	}

	@Override
	public void addNode(Coordinates c) {	//data block is treated as the node
		
		if (headBlockNo == -1) {
			//empty list
			DataBlock db = new DataBlock();
			db.append(c.getX(), c.getY());
			
			this.headBlockNo = 0;
			this.tailBlockNo = 0;
			
			//if ( !(fdb.append(db)) ) return; //file error
			fdb.appendAndUpdateBlockNo(db);
			
		} else {
			
			if ( !(fdb.readBlockToBuffer(tailBlockNo)) ) return;			
			
			DataBlock buffer = fdb.getBuffer();	//buffer contains current tail block
			
			//System.out.println("before append c :  " + buffer.toString() );
			
			
			if ( buffer.append(c.getX(), c.getY()) == -1) {
				
				//System.out.println("after append c :  " + buffer.toString() );
				
				//append new Block
				
				DataBlock new_db = new DataBlock(); //create empty new Block
				new_db.append(c.getX(), c.getY());	//insert coordinates to new Block
				
				int nextBlocknumber = fdb.nextBlockno();	//get next block number from disc (must be equal to tail block number + 1)
				
				//must modify previous tail block number
				buffer.setNext_blockNo(nextBlocknumber);
				
				//System.out.println("old buffer :  " + buffer.toString() );
				
				//write both new block and modified block (buffer) to disc
				fdb.writeBuffer(buffer);
				
				fdb.appendAndUpdateBlockNo(new_db);
				
				this.tailBlockNo = new_db.getBlockNo();
				//System.out.println("NEW BUFFER after append c :  " + new_db.toString() );
				
			} else {
				
				System.out.println("after append c :  " + buffer.toString() );
				//insert to tail block
				fdb.writeBuffer(buffer);
			}
			
			
		}
		
		
		
	}
	
	
	//returns number of disc accesses if node is found,
	//Returns -1 if otherwise
	@Override
	public int findNode(Coordinates c) {
		int disc_access = 0;
		boolean succesfullSearchFlag = false;
		
		if (this.headBlockNo == -1) //empty list 
			return -1;
		
		for (int current_block_number = this.headBlockNo; current_block_number <= tailBlockNo; current_block_number++) {
			
			fdb.readBlockToBuffer(current_block_number); //load current Data block into buffer
			++disc_access;
			
			DataBlock buffer = fdb.getBuffer(); //pointer to buffer
			
			if ( buffer.search(c.getX(), c.getY()) ) {
				//found coordinate
				succesfullSearchFlag = true;
				break;
			}
			
			
			
		}
		
		if (succesfullSearchFlag) return disc_access;
		
		else return -1;
	}
	
}
