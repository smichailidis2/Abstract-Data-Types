package org.tuc.discLists;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import org.tuc.misc.Coordinates;

public class HashArray implements Serializable{
	
	private HashItem[] hasharray = null;
	private int N = 2 << 17;
	private final int M = 500; //hash array size
	
	public HashArray (String fileName) {
		
		this.initialize();
		
	}

	private void initialize() {
		
		hasharray = new HashItem[M];
		
		for (int i = 0; i < M; i++) {
			hasharray[i] = new HashItem(-1,-1);

		}
	}
	
	public int hashValue(int x,int y) {
		return (int) ( ( ( (long)x*N + y) ) % M ); 
		//return (int) ( ( ( (long)x*N + y) ) % 2); TODO UNIT TESTING
	}
	
	public int hashVaule(Coordinates c) {
		return (int) ( ( (long)c.getX()*N + c.getY() ) % M );
		//return (int) ( ( (long)c.getX()*N + c.getY() ) % 2 ); TODO UNIT TESTING
	}
	
	public HashItem gethashitem(int index) {
		return hasharray[index];
	}
	
	public void setHashItem(int index, HashItem h) {
		hasharray[index] = h;
	}
	
	//----------------SERIALIZATION---------------------
	//write to file
	public static void writeToFile(HashArray hash, String fileName) {
		
		ObjectOutputStream oos1 = null;
		
		try {
			oos1 = new ObjectOutputStream(new FileOutputStream(fileName + ".ser"));
			oos1.writeObject(hash);
			oos1.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	//read file
	public static HashArray readFile(String fileName) {
		
		ObjectInputStream ois1 = null;
		
		try {
			ois1 = new ObjectInputStream(new FileInputStream(fileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		HashArray hash = null;
		
		try {
			hash = (HashArray) ois1.readObject();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
		
		
		return hash;
		
	}
	
}
