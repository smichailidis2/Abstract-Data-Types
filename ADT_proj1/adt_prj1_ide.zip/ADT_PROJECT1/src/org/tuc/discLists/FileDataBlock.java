package org.tuc.discLists;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Serializable;

import org.tuc.misc.DataBlock;




public class FileDataBlock {

	private RandomAccessFile raf = null;
	private DataBlock buffer = null;
	
	

	//open file for random access read and write
	public FileDataBlock(String filename) throws FileNotFoundException {		
		
		//open file for random access for read / write, all file updates are written to the disk synchronously.
		raf = new RandomAccessFile(filename, "rwd");   
		
	}
	
	
	public DataBlock getBuffer() {
		return buffer;
	}
	
	
	public long getFileLength() {
		try {
			return raf.length();
		} catch (IOException e) {
			e.printStackTrace();
			return -1;
		}
	}
	


	public boolean readBlockToBuffer(int blockNo){
		
		long filepointer = blockNo2pos(blockNo);	
		byte b[] = new byte[256];
		
		try {
			raf.seek(filepointer);
			raf.readFully(b);	//read 256 bytes from file
			buffer = new DataBlock(b);   //byte and int array
			
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
				
	}

	
	
	//writes data to position given by header's blockno
	public boolean writeBuffer(DataBlock data){
		
		buffer = data;	
		long filepointer = blockNo2pos(buffer.getBlockNo());		//calc filepointer base on blockno
		
		try {
			raf.seek(filepointer);
			raf.write(buffer.convertToByteArray(), 0, 256);   //convert to bytes!!!!! and write to disk 
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
				
	}	
	
	
	//writes data to position
	public boolean writeBuffer(DataBlock data, long position){
		
		buffer = data;	
		
		try {
			raf.seek(position);
			raf.write(buffer.convertToByteArray(), 0, 256);   //convert to bytes!!!!! and write to disk
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
				
	}		
	
	
	//writes current buffer to given position
	public boolean writeBuffer(long position){
		
		
		try {
			raf.seek(position);
			raf.write(buffer.convertToByteArray(), 0, 256);   //convert to bytes and write to disk
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
				
	}			
	

	
	
	//append given data block to the end of file while updating the block's number
	public boolean appendAndUpdateBlockNo(DataBlock data){
		
		//get next blockNo
		int nextblockNo = this.nextBlockno();
		long filelength = getFileLength();
		
		if (filelength == -1)
			return false;
		
		buffer = data;
		buffer.setBlockNo(nextblockNo);		//modify current block number of data to be the correct one
		
		return writeBuffer(filelength);
				
	}
	
	
	public void closeFile(){		
			try {
				raf.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	
	
	//converts block number to absolute position
	private long blockNo2pos(int blockno){
		return blockno << 8; //multiply by 256
	}
	
	
	//converts absolute position to bloc number
	private int pos2blockno(long position){
		return (int) (position >> 8);	//division by 256
	}
	
	
	public int nextBlockno() {
		
		long filelength = getFileLength();
		if (filelength == -1)
			return -1;
		else 
			return pos2blockno(filelength);
		
	}
	
	
	public int tailBlockNo() {
		
		long l = this.getFileLength();
		
		if (l == -1)
			return -1; //error code
		
		else
			return pos2blockno(l)-1;
	}
}
