package org.tuc.main;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import org.tuc.discLists.DiscHashLinkedList;
import org.tuc.discLists.DiscList;
import org.tuc.discLists.HashArray;
import org.tuc.hashList.HashLinkedList;
import org.tuc.linkedlist.List;
import org.tuc.misc.Coordinates;

public class Adt_proj_1 {
	
	public static String filename = "";

	private int n_coordinates;	//number of coordinates loaded
	private Scanner sc = new Scanner(System.in);
	
	List list = null;
	HashLinkedList hash = null;
	DiscList disclist = null;
	DiscHashLinkedList dischash = null;
	


	public static void main(String[] args) {

		
		
		Adt_proj_1 mainInstance = new Adt_proj_1();
		boolean exitflag = false;
		
		while (!exitflag) {
			
			mainInstance.menu();
			int n = mainInstance.prompt();
			
			switch (n) {
			case 0:
				System.out.print("type filename:");
				String fname = mainInstance.sc.next(); //get file name from input	
				mainInstance.n_coordinates = mainInstance.load(fname);				
				
				break;
			case 1:
				if (mainInstance.list == null) {
					System.out.println("NO LIST LOADED");
					break;
				}
				
				int x0 = mainInstance.prompt("Enter x :");
				int y0 = mainInstance.prompt("Enter y :");
				
				Coordinates c0 = new Coordinates(x0,y0);
				System.out.println("coordinates inserted.");
				
				mainInstance.list.addNode(c0);
				
				break;
			case 11:
				if (mainInstance.list == null) {
					System.out.println("NO LIST LOADED");
					break;
				}
				
				int x1 = mainInstance.prompt("Enter x :");
				int y1 = mainInstance.prompt("Enter y :");		
				
				Coordinates c1 = new Coordinates(x1,y1);
				
				int s1 = mainInstance.list.findNode(c1);
				
				String text1 = (s1 == -1) ? "Coordinates not found." : "Coordinates found.";
				System.out.println(text1);
				
				break;
			/*case 12:
				if (mainInstance.list == null) {
					System.out.println("NO LIST LOADED");
					break;
				}
				break;*/
			case 2:
				if (mainInstance.hash == null) {
					System.out.println("NO HASH LIST LOADED");
					break;
				}
				
				int x2 = mainInstance.prompt("Enter x :");
				int y2 = mainInstance.prompt("Enter y :");		
				
				Coordinates c2 = new Coordinates(x2,y2);
				
				mainInstance.hash.addNode(c2);
				
				break;
			case 21:
				if (mainInstance.hash == null) {
					System.out.println("NO HASH LIST LOADED");
					break;
				}
				
				int x3 = mainInstance.prompt("Enter x :");
				int y3 = mainInstance.prompt("Enter y :");		
				
				Coordinates c3 = new Coordinates(x3,y3);
				
				int s2 = mainInstance.hash.findNode(c3);
				
				String text2 = (s2 == -1) ? "Coordinates not dound." : "Coordinates found.";
				
				System.out.println(text2);
				
				break;
			/*case 22: TODO search 100
				if (mainInstance.hash == null) {
					System.out.println("NO HASH LIST LOADED");
					break;
				}
				break;*/
			case 3:
				if (mainInstance.disclist == null) {
					System.out.println("NO DISC LIST LOADED");
					break;
				}
				
				int x4 = mainInstance.prompt("Enter x :");
				int y4 = mainInstance.prompt("Enter y :");		
				
				Coordinates c4 = new Coordinates(x4,y4);
				
				mainInstance.disclist.addNode(c4);
				System.out.println("Coordinates inserted.");
				
				break;
			case 31:
				if (mainInstance.disclist == null) {
					System.out.println("NO DISC LIST LOADED");
					break;
				}
				
				int x5 = mainInstance.prompt("Enter x :");
				int y5 = mainInstance.prompt("Enter y :");		
				
				Coordinates c5 = new Coordinates(x5,y5);
				
				int s3 = mainInstance.disclist.findNode(c5);
				
				String text3 = (s3 == -1) ? "Coordinates not found." : "Coordinates found after " + s3 + " disc accesses.";
				
				System.out.println(text3);
				
				break;
			/*case 32: TODO search 100
				if (mainInstance.disclist == null) {
					System.out.println("NO DISC LIST LOADED");
					break;
				}
				break;*/
			case 4:
				if (mainInstance.dischash == null) {
					System.out.println("NO DISC HASH LIST LOADED");
					break;
				}
				
				int x6 = mainInstance.prompt("Enter x :");
				int y6 = mainInstance.prompt("Enter y :");		
				
				Coordinates c6 = new Coordinates(x6,y6);
				
				mainInstance.dischash.addNode(c6);
				
				break;
			case 41:
				if (mainInstance.dischash == null) {
					System.out.println("NO DISC HASH LIST LOADED");
					break;
				}
				
				int x = mainInstance.prompt("Enter x :");
				int y = mainInstance.prompt("Enter y :");
				
				Coordinates c = new Coordinates(x,y);
				
				int i = mainInstance.dischash.findNode(c);
				
				String text = (i == -1) ? "CORDINATES NOT FOUND" : "COORDINATES FOUND AFTER " + i + " DISC ACCESSES";
				
				System.out.println(text);
				
				break;
				/*case 42: TODO search 100
				if (mainInstance.dischash == null) {
					System.out.println("NO DISC HASH LIST LOADED");
					break;
				}
				break;*/
			case 5:
				
				if ( mainInstance.disclist != null ) {
					mainInstance.disclist.close_list();
				}
				
				if ( mainInstance.dischash != null ) {
					mainInstance.dischash.close_hash();
				}
				exitflag = true;
				break;
			case 9:
				//load existing hash list from disc
				System.out.print("type filename:");
				String hashname = mainInstance.sc.next(); //get file name from input	
				
				String hashlistname = mainInstance.split(hashname,".");
				
				File f = new File(hashname);
				
				if (!f.exists()) {
					System.out.println("FILE NOT FOUND");
					break; 
				}
				
				HashArray ha = HashArray.readFile(hashlistname + ".ser");
				
				mainInstance.dischash = new DiscHashLinkedList(hashlistname,ha);
				
				Adt_proj_1.filename = hashname;
				System.out.println("Loaded serialised hash array");
				
				
				break;
				
			}
		}
		
		System.out.println("programm terminated");
	
	}

	//returns number of loaded coordinates
	//Coordinates read from a given file are loaded into all data structures.
	//At the same time, filename.bin100 file is created containing 100 random coordinates read from 
	//a given bin file.
	private int load(String filename2) {
	
		
		String list_name  = split(filename2, ".");
				
		//Instantiation of disc and memory data structures 
		this.disclist = new DiscList(list_name);
		this.dischash = new DiscHashLinkedList(list_name);
		this.list = new List();
		this.hash = new HashLinkedList();
		
		DataInputStream input = null;
		int x,y;
		int n=0;
		int nmax = 2<<17;
		
		//check if file exists
		File f = new File(filename2);
		
		if ( !f.exists() ) {
			System.out.println("ERROR : FILE NOT FOUND;");
			return 0;
		}
		
		
		//open file for read
		try {
			input = new DataInputStream(new BufferedInputStream(new FileInputStream(filename2)));
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
			return 0;
		}
		
		try {
			
			while ((x=input.readInt()) != -1) {
				
				y = input.readInt();
				
				if (!(x >=0 && x<nmax) || !(y >=0 && y<nmax)) {
					System.out.println("xy out of range");
					System.out.println("file NOT loaded");
					n = 0;
					break;
				} else {
					System.out.println("x=" + x + "  y=" + y);
					
					Coordinates c = new Coordinates(x,y);
					
					//append coordinates read
					list.addNode(c);
					hash.addNode(c);
					
					disclist.addNode(c);
					dischash.addNode(c);
				}
				
				++n;				
			}
									
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
		}
		
		if (n > 0 ) {
			System.out.println(n + " coordinates loaded\n");
			this.filename = filename2;
		}
		
		try {
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}

	private int prompt() {
		int n = -1;
		
		System.out.print(">");
		n = sc.nextInt();
		
		return n;
	}
	
	private int prompt(String s) {
		int n = -1;
		
		System.out.print(s + ">");
		n = sc.nextInt();
		
		return n;
	}

	private void menu() {
		
		System.out.println("\n\nMenu: (number of loaded coordinates=" + n_coordinates + "     filename=" + filename + ")");
		
		System.out.println("  0.  Load coordinates");
		System.out.println("  9.  Load EXISTING hash disc linked list (f.e: K10k.hlst)");
		
		System.out.println("NOTE: all |INSERT| methods do not check if there are identical coordinates in data structure");
		
		System.out.println("\n  1.  (A1.Linked list) INSERT coordinate");
		System.out.println("  11. (A1.Linked list) SEARCH coordinate");
		//System.out.println("  12. (A1.Linked list) SEARCH 100 coordinates");
		System.out.println("  2.  (A2.Hash linked list) INSERT coordinate");
		System.out.println("  21. (A2.Hash linked list) SEARCH coordinate");
		//System.out.println("  22. A2.Hash linked list SEARCH 100 coordinates");
		System.out.println("  3.  (B1.Disk Linked list) INSERT coordinate");
		System.out.println("  31. (B1.Disk Linked list) SEARCH coordinate");
		//System.out.println("  32. B1.Disk Linked list SEARCH 100 coordinates");
		System.out.println("  4.  (B2.Disk Hash Linked list) INSERT coordinate");
		System.out.println("  41. (B2.Disk Hash Linked list) SEARCH coordinate");
		//System.out.println("  42. B2.Disk Hash Linked list SEARCH 100 coordinates");
		System.out.println("  5.  Exit");		
		
	}
	
	
	private String split(String str, String delim) {
		int pos = str.indexOf(delim);
		return str.substring(0, pos);
	}

}
