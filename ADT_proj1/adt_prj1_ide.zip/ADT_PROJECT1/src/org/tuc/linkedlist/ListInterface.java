package org.tuc.linkedlist;

import org.tuc.misc.Coordinates;

public interface ListInterface {
	
	public void addNode(Coordinates c);		//adds node in the end of list

	public int findNode(Coordinates c);		//checks whether or not coordinates exist within anode in list
	//returns -1 if node not found , otherwise return number of searches (or disc accesses).

}
