package org.tuc.linkedlist;

import org.tuc.misc.Coordinates;
import org.tuc.misc.Node;

public class List implements ListInterface{
	
	private int s = 0;  //size counter
	
	private Node headNode;
	private Node tailNode;
	
	public List() {
		this.headNode = null;
		this.tailNode = null;
	}
	
	@Override
	public void addNode(Coordinates c) {
		s++;	//increases list size counter
		
		Node node = new Node(c);
		
		if (headNode == null) {		//if list is empty, make both header and tail point to first node
			this.headNode = node;
			this.tailNode = node;
		}
		else {						//else
			this.tailNode.setNextNode(node);	//add new node
			this.tailNode = node;				//make tail pointer point to last node
		}
		
		
	}

	
	/*
	 * returns number of searches if node is found , otherwise returns -1
	 */
	@Override
	public int findNode(Coordinates c) {
		
		Node np = this.headNode;	//pointer to head	
		if (np == null) {
			return -1;
		}
		
		int j =  1;			
		//where j is the number of searches
		
		int k = 0;
		while ( np != null && (k = np.compare(c) ) == -1) {
			
			//comparison made in the while statement
			
			j++;						//increase counter
			np = np.getNextNode();		//pointer jumps to next node
		
		}
		
		
		
		if (k == -1) {
			j--; //to compensate for the extra search due to next pointer being null
			System.out.println("number of searches : " + j);
			return -1;
		}
		else {
			System.out.println("number of searches : " + j);
			return j;	//returns number of searches
		}

	}
	
	//miscellaneous functions that returns size of List
	public int listSize() {
		return this.s;
	}
	
}
